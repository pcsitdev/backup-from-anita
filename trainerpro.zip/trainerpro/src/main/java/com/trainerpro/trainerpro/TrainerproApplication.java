package com.trainerpro.trainerpro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainerproApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainerproApplication.class, args);
	}

}
